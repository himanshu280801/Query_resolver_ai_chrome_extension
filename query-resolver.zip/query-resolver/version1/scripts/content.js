
let body = document.querySelector("body");

// Create a button and add events
let btnBQ = document.createElement("button");
btnBQ.setAttribute("id", "btnBQ");
btnBQ.addEventListener("click", doSomething);
body.appendChild(btnBQ);

// Speech recognition setup
let speechRecognition = new webkitSpeechRecognition();
speechRecognition.continuous = true;
speechRecognition.interimResults = true;
speechRecognition.lang = "en-us";

let transcript = "";
speechRecognition.onresult = function (event) {
  transcript = "";
  for (let i = 0; i < event.results.length; ++i) {
    transcript += event.results[i][0].transcript;
  }
};

// Keypress event to trigger button click
document.addEventListener("keypress", handleKbd);
function handleKbd(event) {
  if (event.shiftKey && event.altKey && event.code === "KeyQ") {
    btnBQ.click();
  }
}

// Function executed on button click
// Function to format HTML content into readable text
function formatContent(html) {
  // Create a temporary container to parse the HTML
  let container = document.createElement('div');
  container.innerHTML = html;

  let formattedContent = '';

  function processNode(node) {
      if (node.nodeType === Node.TEXT_NODE) {
          formattedContent += node.textContent.trim();
      } else if (node.nodeType === Node.ELEMENT_NODE) {
          switch (node.tagName.toLowerCase()) {
              case 'h1':
                  formattedContent += `\n\n${node.textContent}\n\n`;
                  break;
              case 'h2':
                  formattedContent += `\n\n${node.textContent}\n\n`;
                  break;
              case 'h3':
                  formattedContent += `\n\n${node.textContent}\n\n`;
                  break;
              case 'p':
                  formattedContent += `${node.textContent}\n\n`;
                  break;
              case 'ul':
                  node.childNodes.forEach(child => {
                      if (child.nodeName.toLowerCase() === 'li') {
                          formattedContent += `• ${child.textContent}\n`;
                      }
                  });
                  formattedContent += '\n';
                  break;
              case 'ol':
                  let counter = 1;
                  node.childNodes.forEach(child => {
                      if (child.nodeName.toLowerCase() === 'li') {
                          formattedContent += `${counter++}. ${child.textContent}\n`;
                      }
                  });
                  formattedContent += '\n';
                  break;
              case 'br':
                  formattedContent += '\n';
                  break;
              default:
                  node.childNodes.forEach(child => processNode(child));
          }
      }
  }

  container.childNodes.forEach(child => processNode(child));

  // Remove `**` used for bold text and any other Markdown-like syntax
  formattedContent = formattedContent.replace(/\*\*/g, '');

  return formattedContent.trim();
}

// Function to create and show a custom alert dialog
function showCustomAlert(htmlContent) {
  // Format the content
  let formattedMessage = formatContent(htmlContent);

  // Create the overlay
  let overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.top = '0';
  overlay.style.left = '0';
  overlay.style.width = '100%';
  overlay.style.height = '100%';
  overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
  overlay.style.display = 'flex';
  overlay.style.justifyContent = 'center';
  overlay.style.alignItems = 'center';
  overlay.style.zIndex = '1000';

  // Create the dialog
  let dialog = document.createElement('div');
  dialog.style.backgroundColor = '#333';
  dialog.style.padding = '30px';
  dialog.style.borderRadius = '15px';
  dialog.style.boxShadow = '0px 0px 30px rgba(0, 0, 0, 0.8)';
  dialog.style.maxWidth = '80%';
  dialog.style.maxHeight = '80%';
  dialog.style.overflowY = 'auto';
  dialog.style.color = 'white';

  // Add the content
  let content = document.createElement('pre'); // Use <pre> to preserve formatting
  content.style.fontSize = '16px';
  content.style.lineHeight = '1.6';
  content.textContent = formattedMessage; // Use textContent for plain text

  dialog.appendChild(content);

  // Create the close button
  let closeButton = document.createElement('button');
  closeButton.textContent = 'Close';
  closeButton.style.marginTop = '20px';
  closeButton.style.padding = '15px';
  closeButton.style.fontSize = '18px';
  closeButton.style.backgroundColor = 'teal';
  closeButton.style.border = 'none';
  closeButton.style.color = 'white';
  closeButton.style.borderRadius = '10px';
  closeButton.style.cursor = 'pointer';
  closeButton.addEventListener('click', () => {
      document.body.removeChild(overlay);
  });
  dialog.appendChild(closeButton);

  // Append the dialog to the overlay
  overlay.appendChild(dialog);
  document.body.appendChild(overlay);
}

// Modify the doSomething function to use the custom alert dialog
async function doSomething() {
  if (btnBQ.hasAttribute("listening") == false) {
      btnBQ.setAttribute("listening", true);
      speechRecognition.start();
  } else {
      btnBQ.removeAttribute("listening");
      speechRecognition.stop();
      try {
          const res = await fetch(
              "https://proxy-server-geminiai.vercel.app/api/getresult",
              {
                  method: "POST",
                  headers: {
                      "Content-Type": "application/json",
                  },
                  body: JSON.stringify({ userInput: transcript }),
              }
          );

          const data = await res.json();
          console.log(data.output);
          showCustomAlert(data.output); // Use the custom alert dialog

      } catch (error) {
          console.error("Error:", error);
      }
  }
}


// Convert HTML to text
// Convert HTML to nicely formatted text
function convertHTMLToText(html) {
  let parser = new DOMParser();
  let doc = parser.parseFromString(html, 'text/html');
  
  // Create a div element to manipulate the text
  let textContent = doc.body.textContent || "";

  // Clean up text to make it more readable
  // Replace any specific HTML patterns if needed
  textContent = textContent.replace(/\*\*/g, ""); // Remove '**'
  
  return textContent.trim(); // Trim any extra whitespace
}
